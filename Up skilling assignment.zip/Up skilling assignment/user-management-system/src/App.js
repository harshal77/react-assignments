// App.js
import React, { useState } from 'react';
import { Container, Grid, Typography } from '@mui/material';
import AddUser from "./components/addUser";
import UserList from "./components/userList";
import './App.css';

function App() {
  const [users, setUsers] = useState([]);

  const addUser = (user) => {
    user.id = users.length + 1;
    setUsers([...users, user]);
  };

  const updateUser = (updatedUser) => {
    const updatedUsers = users.map((user) =>
      user.id === updatedUser.id ? updatedUser : user
    );
    setUsers(updatedUsers);
  };

  const deleteUser = (userId) => {
    const updatedUsers = users.filter((user) => user.id !== userId);
    setUsers(updatedUsers);
  };

  return (
    <Container >
      <div className='App'>
        <Grid className='w-40'>
          <AddUser addUser={addUser} />
        </Grid>
        <Grid className='w-100'>
          <UserList
            users={users}
            updateUser={updateUser}
            deleteUser={deleteUser}
          />
        </Grid>
      </div>
    </Container>
  );
}

export default App;
