// components/UserList.js
import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button } from '@mui/material';

const UserList = ({ users, updateUser, deleteUser }) => {
  const [editingId, setEditingId] = useState(null);
  const [editedUser, setEditedUser] = useState({ name: '', email: '', phone: '' });

  const handleEdit = (user) => {
    setEditingId(user.id);
    setEditedUser(user);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditedUser({ name: '', email: '', phone: '' });
  };

  const handleUpdate = () => {
    updateUser(editedUser);
    setEditingId(null);
    setEditedUser({ name: '', email: '', phone: '' });
  };

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Email</TableCell>
            <TableCell>Phone</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user.id}>
              <TableCell>
                {user.id === editingId ? (
                  <input
                    type="text"
                    name="name"
                    value={editedUser.name}
                    onChange={(e) => setEditedUser({ ...editedUser, name: e.target.value })}
                  />
                ) : (
                  user.name
                )}
              </TableCell>
              <TableCell>
                {user.id === editingId ? (
                  <input
                    type="text"
                    name="email"
                    value={editedUser.email}
                    onChange={(e) => setEditedUser({ ...editedUser, email: e.target.value })}
                  />
                ) : (
                  user.email
                )}
              </TableCell>
              <TableCell>
                {user.id === editingId ? (
                  <input
                    type="text"
                    name="phone"
                    value={editedUser.phone}
                    onChange={(e) => setEditedUser({ ...editedUser, phone: e.target.value })}
                  />
                ) : (
                  user.phone
                )}
              </TableCell>
              <TableCell>
                {user.id === editingId ? (
                  <>
                    <Button onClick={handleUpdate} variant="contained" color="primary">
                      Update
                    </Button>
                    <Button onClick={handleCancelEdit} variant="contained" color="secondary">
                      Cancel
                    </Button>
                  </>
                ) : (
                  <>
                    <Button onClick={() => handleEdit(user)} variant="contained" color="primary">
                      Edit
                    </Button>
                    <Button onClick={() => deleteUser(user.id)} variant="contained" color="secondary">
                      Delete
                    </Button>
                  </>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default UserList;
