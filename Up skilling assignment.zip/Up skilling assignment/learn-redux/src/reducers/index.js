import { combineReducers } from "redux";
import counterReducer from "./Counter";
import loggedInReducer from "./isLoggedIn";

const allReducers = combineReducers({
    counter: counterReducer,
    isLogged: loggedInReducer
})

export default allReducers;