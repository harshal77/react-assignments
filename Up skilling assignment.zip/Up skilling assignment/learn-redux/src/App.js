import { useDispatch, useSelector } from "react-redux";
import { descrement, increment } from "./actions";

function App() {
  const counter = useSelector(state => state.counter);
  const isLoggedIn = useSelector(state => state.isLoggedIn);
  const dispatch = useDispatch();

  return (
    <div className="App">
      <h1>Counter : {counter}</h1>
      <button onClick={() => dispatch(increment(5))}>+</button>
      <button onClick={() => dispatch(descrement())}>-</button>
      {isLoggedIn ? 'Logged In': 'Logged Out'}
    </div>
  );
}

export default App;
