export const increment = (number) => {
  return {
    type: 'INCREMENT',
    payload: number
  }
}

export const descrement = () => {
  return {
    type: 'DECREMENT'
  }
}