import React from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';
import Button from '@mui/material/Button';

const TodoList = ({ todos, deleteTodo }) => {
    const table = {
        width: '40%',
        marginTop: '20px'
    }
    const widthCell = { width: '80%' };

    return (
        <TableContainer component={Paper} style={table}>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell style={widthCell}>Task</TableCell>
                        <TableCell>Action</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {todos.map((todo, index) => (
                        <TableRow key={index}>
                            <TableCell style={widthCell}>{todo}</TableCell>
                            <TableCell>
                                <Button variant="outlined" color="error" onClick={() => deleteTodo(index)}>
                                    Delete
                                </Button>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default TodoList;

