// TodoContext.js
import { createContext, useContext, useReducer } from 'react';
const TodoContext = createContext();

export const useTodoContext = () => {
    return useContext(TodoContext);
};

const initialState = {
    todos: [],
};

export const TodoProvider = ({ children }) => {
    const [state] = useReducer(initialState);
    return (
        <TodoContext.Provider value={{ state }}>
            {children}
        </TodoContext.Provider>
    );
};
