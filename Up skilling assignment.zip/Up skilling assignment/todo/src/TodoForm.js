import React, { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';

const TodoForm = ({ addTodo }) => {
  const [todoText, setTodoText] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    if (todoText.trim()) {
      addTodo(todoText);
      setTodoText('');
    }
  };

  const center = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  }

  return (
    <form onSubmit={handleSubmit} style={center}>
      <TextField id="outlined-basic" label="Add a new To-Do" variant="outlined"
        value={todoText}
        onChange={(e) => setTodoText(e.target.value)}
        style={{ marginRight: '10px' }} />
      <Button type="submit" variant="outlined">Add</Button>
    </form>
  );
};

export default TodoForm;
