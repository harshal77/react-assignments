import './App.css';
import { useEffect, useState } from 'react';
import Recipe from './recipes';
import { Environment } from './environment/environment';

const App = () => {
  const [recipes, setRecipes] = useState([]);
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('chicken');

  useEffect(() => {
    getRecipes();
  }, [query])

  const getRecipes = async () => {
    const response = await fetch(`${Environment.baseUrl}?type=public&q=${query}&app_id=${Environment.appId}&app_key=${Environment.appKey}`);
    const data = await response.json();
    setRecipes(data.hits);
  }

  const updateSearch = (event) => {
    setSearch(event.target.value)
  }

  const getSearch = (event) => {
    event.preventDefault();
    setQuery(search)
    setSearch('')
  }

  return (
    <div className='App'>
      <form className='search-form' onSubmit={getSearch}>
        <input className='search-bar'
          type='text'
          value={search}
          onChange={updateSearch
          } />
        <button type='submit' className='search-button'>Search</button>
      </form>
      <div className='recipes'>
        {recipes.map(recipe => (
          <Recipe
            key={recipe.recipe.label}
            title={recipe.recipe.label}
            calories={recipe.recipe.calories}
            image={recipe.recipe.image}
            ingredients={recipe.recipe.ingredients} />
        ))}
      </div>
    </div>
  )
}

export default App;
