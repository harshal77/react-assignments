export class Environment {
    appId = 'eed37f3c';
    appKey = '82f2375c800d92b10fd5704c87467ff8';
    baseUrl = `https://api.edamam.com/api/recipes/v2`;
}