import React, { useState, createContext } from "react";
export const MovieContext = createContext();

export const MovieProvider = props => {
    const [movies, setMovies] = useState([
        {
            name: 'Gadar',
            price: '250',
            id: '1'
        },
        {
            name: 'The nun',
            price: '200',
            id: '2'
        }
    ]);
    return (
        <MovieContext.Provider value={[movies, setMovies]}>
            {props.children}
        </MovieContext.Provider>
    )
}