import React, { useContext } from "react";
import { MovieContext } from "./MovieContext";

const Nav = () => {
    const [movies] = useContext(MovieContext);
    const style = {
        display: 'flex',
        justifyContent: 'space-around',
        alignItems: 'center',
        background: 'cornsilk',
        marginBottom: '10px'
    };
    return (
        <nav style={style}>
            <h3>Movie App</h3>
            <p>List Of Movies : {movies.length}</p>
        </nav>
    )
}

export default Nav;